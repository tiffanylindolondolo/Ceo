import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BriefcaseMedical,
  ClipboardCheck,
  Cross,
  HeartPulse,
  Recycle,
  Siren,
} from "lucide-react";
import { Button } from "../components/ui/button";
import hero from "../assets/ceo-hero-worker.jpg";
import care from "../assets/ceo-occupational-care.jpg";
import ambulance from "../assets/ceo-ambulance-remote.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CEO — Centro de Exames Ocupacionais em Moçambique" },
      { name: "description", content: "Soluções em Saúde e Segurança no Trabalho: exames ocupacionais, atendimento no local, primeiros socorros, ambulâncias e evacuação médica." },
      { property: "og:title", content: "CEO — Centro de Exames Ocupacionais" },
      { property: "og:description", content: "Saúde ocupacional. Onde a sua empresa precisar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://id-preview--525a0f13-2789-4c02-bf94-de60508c93ae.lovable.app/" }],
  }),
  component: Home,
});

const capabilities = [
  { Icon: ClipboardCheck, label: "Exames ocupacionais", to: "/solucoes/exames-ocupacionais" },
  { Icon: HeartPulse, label: "Atendimento no local", to: "/solucoes/atendimento-no-local" },
  { Icon: BriefcaseMedical, label: "Primeiros socorros", to: "/solucoes/primeiros-socorros" },
  { Icon: Siren, label: "Ambulâncias", to: "/solucoes/ambulancias-evacuacao" },
  { Icon: Cross, label: "Evacuação médica", to: "/solucoes/ambulancias-evacuacao" },
  { Icon: Recycle, label: "Resíduos biomédicos", to: "/solucoes/residuos-biomedicos" },
] as const;

const emergencyFlow = ["Emergência", "Triagem", "Mobilização", "Transporte", "Unidade médica"] as const;

function Home() {
  return (
    <>
      <section className="relative min-h-[34rem] overflow-hidden bg-surface-inverse text-surface-inverse-foreground md:min-h-[36rem] xl:min-h-[40rem]">
        <img src={hero} alt="Trabalhador numa operação industrial" width={1600} height={1008} fetchPriority="high" className="absolute inset-0 size-full object-cover object-[58%_center] sm:object-[62%_center] lg:object-center" />
        <div className="absolute inset-0 bg-[linear-gradient(90deg,color-mix(in_oklab,var(--surface-inverse)_97%,transparent)_0%,color-mix(in_oklab,var(--surface-inverse)_84%,transparent)_37%,color-mix(in_oklab,var(--surface-inverse)_18%,transparent)_72%,color-mix(in_oklab,var(--surface-inverse)_3%,transparent)_100%)]" />
        <div className="page-shell relative grid min-h-[34rem] grid-cols-12 items-center py-10 md:min-h-[36rem] md:py-12 xl:min-h-[40rem] xl:py-16">
          <div className="editorial-reveal col-span-12 md:col-span-9 xl:col-span-7">
            <p className="fine-label text-surface-inverse-foreground/70">Pessoas seguras. Operações mais fortes.</p>
            <h1 className="display-hero mt-5 max-w-[10.5ch] md:mt-6">Saúde ocupacional.<br />Onde a sua empresa <em className="font-normal not-italic text-health">precisar.</em></h1>
            <p className="mt-5 max-w-lg text-sm leading-6 text-surface-inverse-foreground/82 md:mt-6 md:leading-7 xl:mt-7">Ajudamos empresas a proteger pessoas, reduzir riscos e garantir a continuidade das suas operações — da admissão ao terreno.</p>
            <div className="mt-6 flex flex-wrap items-center gap-4 md:mt-7 md:gap-5 xl:mt-8">
              <Button variant="teal" asChild><Link to="/solicitar-proposta">Solicitar proposta <ArrowRight /></Link></Button>
              <Link to="/solucoes" className="group inline-flex min-h-11 items-center border-b border-surface-inverse-foreground/60 text-sm font-semibold transition-colors hover:border-health hover:text-health">Conhecer soluções <ArrowRight className="ml-3 size-4 transition-transform duration-300 group-hover:translate-x-1" /></Link>
            </div>
          </div>
          <div className="absolute right-0 top-8 hidden h-28 border-l border-surface-inverse-foreground/35 pl-4 text-[0.62rem] md:block">01</div>
          <div className="absolute bottom-6 right-0 hidden text-right md:block"><span className="fine-label text-surface-inverse-foreground">Moçambique</span><span className="mt-1 block text-[0.55rem] uppercase tracking-[0.16em] text-surface-inverse-foreground/60">No terreno com a sua operação</span></div>
        </div>
      </section>

      <section className="bg-card py-12 md:py-14 xl:py-20">
        <div className="page-shell">
          <div className="grid grid-cols-12 gap-y-6">
            <div className="col-span-12 xl:col-span-6"><p className="fine-label text-accent-strong">Da admissão à emergência</p><h2 className="display-section mt-4 max-w-[11ch] text-primary">Uma única estrutura de saúde ocupacional.</h2></div>
            <p className="col-span-12 max-w-lg self-end text-sm leading-7 text-muted-foreground xl:col-span-5 xl:col-start-8">Soluções integradas para empresas que valorizam a vida, a produtividade e a continuidade das suas operações.</p>
          </div>
          <div className="mt-9 grid grid-cols-2 border-y border-border md:mt-10 md:grid-cols-3 xl:mt-12 xl:grid-cols-6">
            {capabilities.map(({ Icon, label, to }, index) => <Link key={label} to={to} className={`group relative flex min-h-24 md:min-h-28 flex-col items-center justify-center gap-3 px-3 text-center ${index % 2 ? "border-l" : ""} md:border-l md:first:border-l-0`}><Icon strokeWidth={1.35} className="size-6 text-primary transition-colors duration-300 group-hover:text-accent-strong" /><span className="max-w-28 text-[0.7rem] font-medium leading-4 text-primary">{label}</span><span className="absolute inset-x-5 bottom-0 h-px origin-left scale-x-0 bg-accent-strong transition-transform duration-300 group-hover:scale-x-100" /></Link>)}
          </div>
        </div>
      </section>

      <section className="grid bg-background xl:grid-cols-2">
        <div className="flex min-h-[20rem] items-center px-5 py-12 md:min-h-[22rem] md:px-10 md:py-14 xl:px-[max(3rem,calc((100vw-90rem)/2))] xl:py-16">
          <div className="max-w-xl"><p className="fine-label text-accent-strong">Saúde e produtividade</p><h2 className="display-section mt-4 text-primary">Empresas mais seguras começam pelas pessoas.</h2><p className="mt-6 max-w-lg text-sm leading-7 text-muted-foreground">Prevenimos riscos, monitorizamos a saúde da sua equipa e apoiamos a sua operação com soluções adaptadas à realidade da sua empresa.</p><Button variant="inverse" className="mt-8" asChild><Link to="/contacto">Falar com um especialista <ArrowRight /></Link></Button></div>
        </div>
        <div className="relative min-h-[22rem] overflow-hidden md:min-h-[28rem] xl:min-h-[34rem]"><img src={care} loading="lazy" width={1600} height={1000} alt="Profissional de saúde atende um trabalhador" className="size-full object-cover" /><div className="absolute inset-y-0 right-0 flex w-28 items-center bg-surface-inverse/65 px-4 text-surface-inverse-foreground backdrop-blur-[2px] md:w-32 md:px-5"><div className="space-y-4 text-[0.62rem] md:space-y-5">{["Prevenir", "Acompanhar", "Proteger", "Desenvolver"].map((item, index) => <div key={item} className={`flex items-center gap-3 ${index === 0 ? "text-surface-inverse-foreground" : "text-surface-inverse-foreground/55"}`}>{index === 0 && <span className="size-1.5 rounded-full bg-health" />}{item}</div>)}</div></div><p className="absolute bottom-5 right-4 fine-label text-surface-inverse-foreground md:bottom-6 md:right-5">Saúde hoje.<br />Operações amanhã.</p></div>
      </section>

      <section className="relative isolate overflow-hidden bg-surface-inverse text-surface-inverse-foreground">
        <img src={ambulance} loading="lazy" width={1600} height={1000} alt="Unidade médica móvel numa operação remota" className="absolute inset-0 -z-10 size-full object-cover object-[66%_center] opacity-90" />
        <div className="absolute inset-0 -z-10 bg-[linear-gradient(90deg,var(--surface-inverse)_0%,color-mix(in_oklab,var(--surface-inverse)_96%,transparent)_32%,color-mix(in_oklab,var(--surface-inverse)_48%,transparent)_68%,color-mix(in_oklab,var(--surface-inverse)_10%,transparent)_100%)]" />
        <div className="page-shell grid min-h-[26rem] md:min-h-[30rem] grid-cols-12 items-center gap-y-10 py-12 md:py-14 lg:min-h-[32rem]">
          <div className="col-span-12 md:col-span-5"><p className="fine-label text-surface-inverse-foreground/65">Sempre que for necessário</p><h2 className="display-section mt-4 max-w-[9ch]">Preparados para responder.</h2><p className="mt-6 max-w-sm text-sm leading-7 text-surface-inverse-foreground/72">Estrutura, equipa e meios para apoio médico, evacuação e atendimento em contextos operacionais exigentes.</p><Button variant="outline" className="mt-7 border-surface-inverse-foreground/45 bg-transparent text-surface-inverse-foreground hover:border-health hover:text-health" asChild><Link to="/solucoes/ambulancias-evacuacao">Saber mais <ArrowRight /></Link></Button></div>
          <ol className="col-span-12 border-l border-surface-inverse-foreground/35 md:col-span-3 md:col-start-6">{emergencyFlow.map((item, index) => <li key={item} className="grid grid-cols-[2rem_1fr] gap-3 py-2.5 pl-4 text-xs"><span className="text-health">0{index + 1}</span><span>{item}</span></li>)}</ol>
          <div className="col-span-12 self-start justify-self-end md:col-span-3 md:col-start-10"><div className="flex items-center gap-3 bg-background/90 px-5 py-3 text-primary"><span className="size-2 animate-pulse rounded-full bg-health" /><span className="fine-label">Em campo<br />pela sua equipa</span></div></div>
        </div>
      </section>
    </>
  );
}