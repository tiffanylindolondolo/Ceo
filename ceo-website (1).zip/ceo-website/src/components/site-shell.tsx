import { Link } from "@tanstack/react-router";
import { Menu, X, UserRound, ArrowRight } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Brand } from "./brand";
import { Button } from "./ui/button";
import { contact } from "../data/site";

const nav = [["Soluções", "/solucoes"], ["Empresas", "/solucoes/atendimento-no-local"], ["Emergência", "/solucoes/ambulancias-evacuacao"], ["Sobre", "/sobre"], ["Contacto", "/contacto"]] as const;

export function SiteShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false); const [scrolled, setScrolled] = useState(false);
  useEffect(() => { const onScroll = () => setScrolled(window.scrollY > 20); onScroll(); window.addEventListener("scroll", onScroll, { passive: true }); return () => window.removeEventListener("scroll", onScroll); }, []);
  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", closeOnEscape);
    return () => { document.body.style.overflow = previousOverflow; window.removeEventListener("keydown", closeOnEscape); };
  }, [open]);
  return <div className="min-h-screen bg-background text-foreground">
    <header className={`sticky inset-x-0 top-0 z-50 transition-colors duration-300 ${open ? "border-b border-border bg-background" : scrolled ? "border-b border-border bg-background/92 backdrop-blur-md" : "bg-background"}`}>
      <div className="page-shell relative z-50 flex h-[4.5rem] items-center justify-between md:h-[4.75rem] xl:h-[5.75rem]"><Brand/>
        <nav aria-label="Navegação principal" className="hidden items-center gap-9 xl:flex">{nav.map(([label,to]) => <Link key={to} to={to} activeProps={{className:"text-accent-strong"}} className="text-[0.68rem] font-semibold text-primary transition-colors hover:text-accent-strong">{label}</Link>)}</nav>
        <div className="hidden items-center gap-3 xl:flex"><Button variant="ghost" size="sm" asChild><Link to="/portal"><UserRound className="size-3.5" /> Portal do Cliente</Link></Button><Button variant="inverse" size="sm" className="min-h-10 px-5" asChild><Link to="/solicitar-proposta">Solicitar proposta <ArrowRight /></Link></Button></div>
        <Button variant="ghost" size="icon" className="size-10 xl:hidden" aria-label={open ? "Fechar menu" : "Abrir menu"} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X/> : <Menu/>}</Button>
      </div>
      {open && <div className="fixed inset-0 z-40 h-[100dvh] overflow-hidden bg-background xl:hidden"><nav className="page-shell flex h-[100dvh] flex-col overflow-y-auto pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-[calc(4.5rem+max(1.25rem,env(safe-area-inset-top)))] md:pt-[calc(4.75rem+2rem)]" aria-label="Navegação móvel">{nav.map(([label,to]) => <Link key={to} to={to} onClick={()=>setOpen(false)} className="border-b border-border py-3.5 font-[family-name:var(--font-display)] text-[1.65rem] leading-none font-normal text-primary md:py-4 md:text-[1.85rem]">{label}</Link>)}<Link to="/portal" onClick={()=>setOpen(false)} className="py-4 text-sm font-semibold md:py-5">Portal do Cliente</Link><Button variant="teal" className="min-h-10 self-stretch px-5 md:self-start" asChild><Link to="/solicitar-proposta" onClick={()=>setOpen(false)}>Solicitar proposta <ArrowRight /></Link></Button></nav></div>}
    </header>
    <main>{children}</main>
    <footer className="border-t border-border bg-card py-8 text-primary"><div className="page-shell grid items-center gap-7 md:grid-cols-[1.25fr_1fr_1fr]"><div><Brand/><p className="mt-2 text-[0.62rem] uppercase tracking-[0.14em] text-muted-foreground">Centro de Exames Ocupacionais<br />Saúde & Consultoria</p></div><div className="text-xs leading-6 text-muted-foreground"><p className="font-semibold text-primary">Nampula, Moçambique</p><p>{contact.address}</p></div><div className="text-xs leading-6 md:text-right"><a href={contact.phoneHref} className="block hover:text-accent-strong">{contact.phone}</a><a href={`mailto:${contact.email}`} className="block hover:text-accent-strong">{contact.email}</a><div className="mt-2 flex gap-5 md:justify-end"><Link to="/portal">Portal</Link><Link to="/privacidade">Privacidade</Link></div></div></div></footer>
  </div>;
}