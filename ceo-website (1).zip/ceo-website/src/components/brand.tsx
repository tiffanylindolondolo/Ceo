import { Link } from "@tanstack/react-router";
import logoUrl from "../assets/ceo-logo.png";

export function Brand({ inverse = false }: { inverse?: boolean }) {
  return (
    <Link to="/" aria-label="CEO Saúde & Consultoria — página inicial" className="inline-flex shrink-0 items-center">
      <img
        src={logoUrl}
        alt="CEO Saúde & Consultoria"
        width={900}
        height={375}
        className={`h-auto w-[7.5rem] object-contain sm:w-[8rem] md:w-[8.5rem] xl:w-[10.5rem] ${inverse ? "brightness-0 invert" : ""}`}
      />
    </Link>
  );
}
