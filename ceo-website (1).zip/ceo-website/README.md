# CEO — Centro de Exames Ocupacionais | Saúde & Consultoria

Website institucional da CEO Saúde & Consultoria (Nampula, Moçambique).

## Tecnologia

- React 19 + TypeScript
- TanStack Start (React) com routing baseado em ficheiros (`src/routes/`)
- Vite
- Tailwind CSS v4 (`src/styles.css`)

## Requisitos

- Node.js 20 ou superior
- npm (ou bun / pnpm)

## Comandos

```sh
npm install      # instalar dependências
npm run dev      # servidor de desenvolvimento
npm run build    # build de produção
npm run preview  # pré-visualizar o build
npm run lint     # análise de código
```

## Estrutura

```
public/            favicon, robots.txt, sitemap.xml
src/assets/        fotografias e logótipo CEO
src/components/    componentes reutilizáveis (header, footer, UI)
src/data/site.ts   conteúdo institucional e contactos
src/routes/        páginas (/, /solucoes, /sobre, /contacto, ...)
src/styles.css     design system (cores, tipografia, utilitários)
```

As fontes (Manrope e Newsreader) são carregadas via Google Fonts em `src/routes/__root.tsx`.

## Deployment

O projeto é uma aplicação TanStack Start com renderização no servidor. O build gera
uma saída em `.output/` pronta para plataformas com suporte a Node/Edge:

- **Vercel**, **Netlify**, **Cloudflare Pages** — detectam Vite/TanStack Start automaticamente
  (comando de build: `npm run build`).

**GitHub Pages não é adequado** para esta arquitetura, porque só serve ficheiros estáticos
e o projeto usa renderização no servidor. Forçar GitHub Pages exigiria reescrever a
aplicação como SPA puro. Use Vercel, Netlify ou Cloudflare Pages.

## Publicação em repositório Git

```sh
git init
git add .
git commit -m "Initial CEO website"
git remote add origin <url-do-seu-repositorio>
git push -u origin main
```

## Notas

- Não existem chaves, credenciais ou variáveis de ambiente privadas neste projeto.
- Antes de publicar num domínio próprio, actualize o URL canónico em `src/routes/index.tsx`
  e os endereços em `public/sitemap.xml` e `public/robots.txt`.
- O formulário de proposta valida os dados no navegador e mostra instruções de contacto
  directo; não envia email automaticamente.
